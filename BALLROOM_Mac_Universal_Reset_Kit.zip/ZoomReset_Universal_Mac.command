#!/usr/bin/env bash
# ZoomReset_Universal_Mac.command
# Universal macOS Zoom reset tool for Intel + Apple Silicon Macs.
# Double-click to run in Terminal.

set -u -o pipefail

SCRIPT_NAME="ZoomReset_Universal_Mac.command"
LOG_FILE="$HOME/Desktop/ZoomReset_$(date +%Y%m%d_%H%M%S).log"

DELETE_LOCAL_RECORDINGS=1
DELETE_SHARED_RECORDINGS=1

log() {
  local msg="$*"
  printf '[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$msg" | tee -a "$LOG_FILE"
}

warn() {
  log "WARNING: $*"
}

run_quiet() {
  "$@" >>"$LOG_FILE" 2>&1
  return $?
}

remove_path() {
  local target="$1"
  if [[ -e "$target" ]]; then
    rm -rf "$target" >>"$LOG_FILE" 2>&1 && log "Removed: $target" || warn "Could not remove: $target"
  else
    log "Not found, skipped: $target"
  fi
}

remove_with_sudo() {
  local target="$1"
  if [[ "$HAVE_SUDO" -eq 1 ]]; then
    if [[ -e "$target" ]]; then
      sudo rm -rf "$target" >>"$LOG_FILE" 2>&1 && log "Removed with sudo: $target" || warn "Could not remove with sudo: $target"
    else
      log "Not found, skipped: $target"
    fi
  else
    warn "Skipping system path without admin rights: $target"
  fi
}

print_header() {
  echo "=============================="
  echo " BALLROOM ZOOM RESET FOR MAC "
  echo "=============================="
  echo
  echo "This will close Zoom, clear Zoom data, and try to relaunch it."
  echo "Local Zoom recordings may be deleted."
  echo
}

check_platform() {
  if [[ "$(uname -s)" != "Darwin" ]]; then
    echo "This script is for macOS only."
    exit 1
  fi
}

get_arch() {
  local arch
  arch="$(uname -m 2>/dev/null || echo unknown)"
  case "$arch" in
    arm64) echo "Apple Silicon (arm64)" ;;
    x86_64) echo "Intel (x86_64)" ;;
    *) echo "$arch" ;;
  esac
}

prompt_sudo() {
  HAVE_SUDO=0

  if [[ "$EUID" -eq 0 ]]; then
    HAVE_SUDO=1
    log "Already running with admin rights."
    return 0
  fi

  echo "macOS may ask for your password so the script can clean shared Zoom folders too."
  if sudo -v; then
    HAVE_SUDO=1
    log "Admin rights granted."
  else
    HAVE_SUDO=0
    warn "Admin rights were not granted. Continuing with current-user cleanup only."
  fi
}

stop_zoom() {
  log "Stopping Zoom processes..."
  run_quiet osascript -e 'tell application "zoom.us" to quit' || true
  run_quiet osascript -e 'tell application "Zoom Workplace" to quit' || true
  run_quiet osascript -e 'tell application "Zoom" to quit' || true
  run_quiet pkill -x "zoom.us" || true
  run_quiet pkill -x "Zoom" || true
  run_quiet pkill -x "Zoom Workplace" || true
  run_quiet pkill -x "CptHost" || true
  run_quiet pkill -x "zTscoder" || true
  sleep 2
  log "Zoom stop sequence finished."
}

clean_user() {
  log "Cleaning Zoom data for current user: $HOME"

  remove_path "$HOME/Library/Application Support/zoom.us"
  remove_path "$HOME/Library/Application Support/Zoom"
  remove_path "$HOME/Library/Caches/us.zoom.xos"
  remove_path "$HOME/Library/Caches/zoom.us"
  remove_path "$HOME/Library/Preferences/us.zoom.xos.plist"
  remove_path "$HOME/Library/Preferences/zoom.us.plist"
  remove_path "$HOME/Library/Saved Application State/us.zoom.xos.savedState"
  remove_path "$HOME/Library/Saved Application State/zoom.us.savedState"
  remove_path "$HOME/Library/HTTPStorages/us.zoom.xos"
  remove_path "$HOME/Library/HTTPStorages/us.zoom.xos.binarycookies"
  remove_path "$HOME/Library/WebKit/us.zoom.xos"
  remove_path "$HOME/Library/Cookies/us.zoom.xos.binarycookies"
  remove_path "$HOME/Library/Logs/zoom.us"

  if [[ "$DELETE_LOCAL_RECORDINGS" -eq 1 ]]; then
    remove_path "$HOME/Documents/Zoom"
  else
    log "Local recordings retained by configuration."
  fi

  if [[ -d "$HOME/Library/Logs" ]]; then
    while IFS= read -r found; do
      remove_path "$found"
    done < <(find "$HOME/Library/Logs" -maxdepth 1 \( -iname 'zoom*' -o -iname 'us.zoom*' \) 2>/dev/null)
  fi
}

clean_system() {
  log "Cleaning shared and machine-level Zoom data..."

  remove_with_sudo "/Library/Application Support/zoom.us"
  remove_with_sudo "/Library/Application Support/Zoom"
  remove_with_sudo "/Library/Logs/zoom.us"
  remove_with_sudo "/Library/Preferences/us.zoom.xos.plist"
  remove_with_sudo "/Library/Preferences/zoom.us.plist"
  remove_with_sudo "/Users/Shared/zoom.us"
  remove_with_sudo "/Users/Shared/Zoom"
  remove_with_sudo "/Users/Shared/ZoomInstaller"

  if [[ "$DELETE_SHARED_RECORDINGS" -eq 1 ]]; then
    remove_with_sudo "/Users/Shared/Zoom/Recordings"
  else
    log "Shared recordings retained by configuration."
  fi
}

find_zoom_app() {
  local candidates=(
    "/Applications/Zoom Workplace.app"
    "/Applications/zoom.us.app"
    "/Applications/Zoom.app"
    "$HOME/Applications/Zoom Workplace.app"
    "$HOME/Applications/zoom.us.app"
    "$HOME/Applications/Zoom.app"
  )

  local app
  for app in "${candidates[@]}"; do
    if [[ -d "$app" ]]; then
      printf '%s\n' "$app"
      return 0
    fi
  done

  local mdfind_result
  mdfind_result="$(mdfind 'kMDItemKind == "Application" && (kMDItemFSName == "Zoom Workplace.app" || kMDItemFSName == "zoom.us.app" || kMDItemFSName == "Zoom.app")' 2>/dev/null | head -n 1 || true)"
  if [[ -n "$mdfind_result" ]]; then
    printf '%s\n' "$mdfind_result"
    return 0
  fi

  return 1
}

launch_zoom() {
  local zoom_app
  zoom_app="$(find_zoom_app || true)"

  if [[ -n "$zoom_app" ]]; then
    log "Launching Zoom from: $zoom_app"
    open "$zoom_app" >>"$LOG_FILE" 2>&1 && return 0
    warn "Open failed for detected app path: $zoom_app"
  fi

  log "Trying fallback app names..."
  open -a "Zoom Workplace" >>"$LOG_FILE" 2>&1 && return 0
  open -a "zoom.us" >>"$LOG_FILE" 2>&1 && return 0
  open -a "Zoom" >>"$LOG_FILE" 2>&1 && return 0

  warn "Zoom could not be relaunched automatically."
  warn "Open Zoom manually from Applications."
  return 1
}

main() {
  check_platform
  print_header

  mkdir -p "$(dirname "$LOG_FILE")"
  : > "$LOG_FILE"

  log "Script started: $SCRIPT_NAME"
  log "macOS user: $USER"
  log "Detected CPU architecture: $(get_arch)"
  log "Log file: $LOG_FILE"
  log "DELETE_LOCAL_RECORDINGS=$DELETE_LOCAL_RECORDINGS"
  log "DELETE_SHARED_RECORDINGS=$DELETE_SHARED_RECORDINGS"

  prompt_sudo
  stop_zoom
  clean_user
  clean_system
  launch_zoom || true

  echo
  echo "Done."
  echo "A log file was saved to your Desktop:"
  echo "$LOG_FILE"
  echo
  echo "You can close this Terminal window."
  log "Script finished."
}

main "$@"
