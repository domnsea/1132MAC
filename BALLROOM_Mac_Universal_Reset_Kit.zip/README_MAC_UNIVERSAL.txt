BALLROOM MAC UNIVERSAL ZOOM RESET KIT

WHAT THIS DOES

This Mac script works on:
- Intel Macs
- Apple Silicon Macs
- newer Zoom Workplace installs
- older zoom.us installs

It closes Zoom, deletes Zoom data, writes a Desktop log file, and then tries to relaunch Zoom.

It is configured to delete:
- local Zoom data in the current Mac user account
- shared/system Zoom data if admin permission is granted
- local Documents/Zoom recordings
- shared Zoom recording folders when available

IMPORTANT WARNING

This can permanently delete local Zoom recordings.
Do not run it if you need to keep those files.

FILES IN THIS KIT

- ZoomReset_Universal_Mac.command
- BALLROOM_Mac_Universal_Zoom_Reset_Guide.pdf
- README_MAC_UNIVERSAL.txt
- LICENSE_MIT.txt

HOW TO USE

1. Double-click ZoomReset_Universal_Mac.command
2. Terminal will open
3. Read the prompt and continue
4. Enter the Mac password if asked
5. Let the script finish
6. Zoom should try to reopen automatically

IF MACOS BLOCKS THE FILE

Try this:
- right-click the file
- click Open
- confirm Open again

If needed, remove quarantine in Terminal:
xattr -d com.apple.quarantine "ZoomReset_Universal_Mac.command"

WHAT IT DOES NOT DO

- It does not repair internet problems
- It does not fix Zoom account bans or server-side restrictions
- It does not reinstall Zoom
- It does not preserve local recordings

EXTRA NOTE

A log file is saved to the Desktop so the user can see what was removed or skipped.
